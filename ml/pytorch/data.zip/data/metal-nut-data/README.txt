METAL NUT DATA SET
- Credits to https://www.mvtec.com/company/research/datasets
- See also: https://www.mvtec.com/company/research/datasets/mvtec-ad

ATTRIBUTION

Paul Bergmann, Michael Fauser, David Sattlegger, Carsten Steger. 
MVTec AD - A Comprehensive Real-World Dataset for Unsupervised Anomaly Detection; 
in: IEEE Conference on Computer Vision and Pattern Recognition (CVPR), June 2019

LICENSE

The data is released under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 
International License (CC BY-NC-SA 4.0). For using the data in a way that falls under 
the commercial use clause of the license, please contact us via the form below.